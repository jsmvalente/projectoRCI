//
//  VerifyMalloc.h
//  projectoRCI
//
//  Created by João Valente on 08/03/2017.
//  Copyright © 2017 João Valente. All rights reserved.
//

#ifndef VerifyMalloc_h
#define VerifyMalloc_h

#include "Defs.h"

#endif /* VerifyMalloc_h */

void VerifyMalloc(void *);
